package com.example.theme;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Objects;

public class Answer2 extends AppCompatActivity {

    private String data,getdata = "";
    private CancelableEdittext edittext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer2);

        edittext = findViewById(R.id.edit_text_2);

        edittext.requestFocus();

        Button save = findViewById(R.id.save_data);
        save.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                data = Objects.requireNonNull(edittext.getText()).toString().trim();
                if (data.isEmpty()) {
                    Toast.makeText(Answer2.this,"Field is Empty...",Toast.LENGTH_SHORT).show();
                }
                else {
                    try {
                        File root = new File(Environment.getExternalStorageDirectory(), "Data");
                        if (!root.exists()) {
                            root.mkdirs();
                        }
                        File gpxfile = new File(root, "Record.txt");
                        FileWriter writer = new FileWriter(gpxfile);
                        writer.append(data);
                        writer.flush();
                        writer.close();
                        Toast.makeText(Answer2.this, "Data Saved Successfully...", Toast.LENGTH_SHORT).show();
                        edittext.setText("");
                        edittext.hideButton();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        Button show = findViewById(R.id.show_data);
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String line;
                    String path = Environment.getExternalStorageDirectory()+"/Data/Record.txt";
                    FileReader fileReader = new FileReader(new File(path));
                    StringBuilder builder = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(fileReader);
                    while ((line = bufferedReader.readLine()) != null) {
                        builder.append(line);
                        builder.append("\n");
                    }
                    getdata = builder.toString();
                    if (getdata.isEmpty()) {
                        Toast.makeText(Answer2.this,"File is Empty...",Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(Answer2.this,getdata,Toast.LENGTH_SHORT).show();
                    }
                }
                catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
