package com.example.theme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void function(View view) {
        switch (view.getId()) {
            case R.id.theme:
                Intent intent = new Intent(MainActivity.this,Answer1.class);
                startActivity(intent);
                break;
            case R.id.answer2:
                Intent intent1 = new Intent(MainActivity.this,Answer2.class);
                startActivity(intent1);
                break;
            case R.id.answer3:
                Intent intent2 = new Intent(MainActivity.this,Answer3.class);
                startActivity(intent2);
                break;
        }
    }
}
