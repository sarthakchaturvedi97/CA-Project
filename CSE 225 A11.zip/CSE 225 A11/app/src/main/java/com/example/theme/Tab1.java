package com.example.theme;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Tab1 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab1, container, false);

        String color_name;
        final RadioGroup radioGroup = view.findViewById(R.id.radio_grp);

        try {
            String path = Environment.getExternalStorageDirectory()+"/Theme/Color";
            FileReader fileReader = new FileReader(new File(path));
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            color_name = bufferedReader.readLine();
            if (!color_name.isEmpty()) {
                radioGroup.check(getId(color_name));
            }
            else {
                radioGroup.check(R.id.radio_blue);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                String col = color(checkedId);
                try {
                    File root = new File(Environment.getExternalStorageDirectory(), "Theme");
                    if (!root.exists()) {
                        root.mkdirs();
                    }
                    File file = new File(root, "Color");
                    FileWriter writer = new FileWriter(file);
                    writer.append(col);
                    writer.flush();
                    writer.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        return view;
    }

    @SuppressLint("ResourceAsColor")
    private String color(int id) {

        switch (id) {
            case R.id.radio_blue:
                Tab2.layout.setBackgroundColor(Color.BLUE);
                return "Blue";
            case R.id.radio_red:
                Tab2.layout.setBackgroundColor(Color.RED);
                return "Red";
            case R.id.radio_yellow:
                Tab2.layout.setBackgroundColor(Color.YELLOW);
                return "Yellow";
            case R.id.radio_green:
                Tab2.layout.setBackgroundColor(Color.GREEN);
                return "Green";
            case R.id.radio_black:
                Tab2.layout.setBackgroundColor(Color.BLACK);
                return "Black";
            case R.id.radio_purple:
                Tab2.layout.setBackgroundColor(Color.parseColor("#9c27b0"));
                return "Purple";
            case R.id.radio_orange:
                Tab2.layout.setBackgroundColor(Color.parseColor("#ff8f00"));
                return "Orange";
            case R.id.radio_brown:
                Tab2.layout.setBackgroundColor(Color.parseColor("#4e342e"));
                return "Brown";
            case R.id.radio_pink:
                Tab2.layout.setBackgroundColor(Color.parseColor("#e91e63"));
                return "Pink";
            case R.id.radio_mehroon:
                Tab2.layout.setBackgroundColor(Color.parseColor("#ad1457"));
                return "Mehroon";
        }
        return "";
    }

    private int getId(String color) {

        switch (color) {
            case "Blue":
                return R.id.radio_blue;
            case "Red":
                return R.id.radio_red;
            case "Yellow":
                return R.id.radio_yellow;
            case "Green":
                return R.id.radio_green;
            case "Black":
                return R.id.radio_black;
            case "Purple":
                return R.id.radio_purple;
            case "Orange":
                return R.id.radio_orange;
            case "Brown":
                return R.id.radio_brown;
            case "Pink":
                return R.id.radio_pink;
            case "Mehroon":
                return R.id.radio_mehroon;
        }
        return R.id.radio_blue;
    }
}
