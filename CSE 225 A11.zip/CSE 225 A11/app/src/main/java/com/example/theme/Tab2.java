package com.example.theme;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Tab2 extends Fragment {

    public static RelativeLayout layout;

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab2, container, false);

        layout = view.findViewById(R.id.tab2);

        try {
            String path = Environment.getExternalStorageDirectory()+"/Theme/Color";
            File file = new File(path);
            if (!file.exists()) {
                setColor("Blue");
            }
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String color_name = bufferedReader.readLine();
            if (!color_name.isEmpty()) {
                setColor(color_name);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return view;
    }

    private void setColor(String color) {

        switch (color) {
            case "Blue":
                Tab2.layout.setBackgroundColor(Color.BLUE);
                break;
            case "Red":
                Tab2.layout.setBackgroundColor(Color.RED);
                break;
            case "Yellow":
                Tab2.layout.setBackgroundColor(Color.YELLOW);
                break;
            case "Green":
                Tab2.layout.setBackgroundColor(Color.GREEN);
                break;
            case "Black":
                Tab2.layout.setBackgroundColor(Color.BLACK);
                break;
            case "Purple":
                Tab2.layout.setBackgroundColor(Color.parseColor("#9c27b0"));
                break;
            case "Orange":
                Tab2.layout.setBackgroundColor(Color.parseColor("#ff8f00"));
                break;
            case "Brown":
                Tab2.layout.setBackgroundColor(Color.parseColor("#4e342e"));
                break;
            case "Pink":
                Tab2.layout.setBackgroundColor(Color.parseColor("#e91e63"));
                break;
            case "Mehroon":
                Tab2.layout.setBackgroundColor(Color.parseColor("#ad1457"));
                break;
        }
    }
}
